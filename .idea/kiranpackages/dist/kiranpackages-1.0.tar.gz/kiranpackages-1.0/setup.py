from setuptools import setup

setup(name = 'kiranpackages',
    version='1.0',  
    description= "this is kiran package",
    long_description="this is long description of kiran package",
    author="kiran",
   packages=['kiranpackages'],
install_requires=[] )
