class MyClass:
    def __init__(self):
        print("this is constructor")

    def func(self,str1):
        print("this is function")
        return str1

